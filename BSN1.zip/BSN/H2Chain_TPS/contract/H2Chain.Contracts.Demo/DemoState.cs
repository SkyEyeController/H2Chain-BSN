﻿using H2Chain.Standards.ACS1;
using H2Chain.Standards.ACS3;
using H2Chain.Contracts.Consensus.AEDPoS;
using H2Chain.Contracts.MultiToken;
using H2Chain.Sdk.CSharp.State;
using H2Chain.Types;

namespace H2Chain.Contracts.Parliament
{
    public class ParliamentState : ContractState
    {
        public MappedState<Address, Organization> Organizations { get; set; }

        public BoolState Initialized { get; set; }

        public SingletonState<Address> DefaultOrganizationAddress { get; set; }

        internal AEDPoSContractContainer.AEDPoSContractReferenceState ConsensusContract { get; set; }
        internal TokenContractContainer.TokenContractReferenceState TokenContract { get; set; }
        public MappedState<Hash, ProposalInfo> Proposals { get; set; }
        public MappedState<string, MethodFees> TransactionFees { get; set; }

        public SingletonState<ProposerWhiteList> ProposerWhiteList { get; set; }
        public SingletonState<AuthorityInfo> MethodFeeController { get; set; }
    }
}