﻿using H2Chain.Contracts.MultiToken;
using H2Chain.Contracts.Parliament;

namespace H2Chain.Contracts.Profit
{
    public partial class ProfitContractState
    {
        internal TokenContractContainer.TokenContractReferenceState TokenContract { get; set; }
        internal ParliamentContractContainer.ParliamentContractReferenceState ParliamentContract { get; set; }
    }
}