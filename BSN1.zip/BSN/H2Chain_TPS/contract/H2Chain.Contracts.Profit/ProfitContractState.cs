﻿using H2Chain.Standards.ACS1;
using H2Chain.Sdk.CSharp.State;
using H2Chain.Types;

namespace H2Chain.Contracts.Profit
{
    public partial class ProfitContractState : ContractState
    {
        public MappedState<Hash, Scheme> SchemeInfos { get; set; }

        public MappedState<Address, DistributedProfitsInfo> DistributedProfitsMap { get; set; }

        public MappedState<Hash, Address, ProfitDetails> ProfitDetailsMap { get; set; }

        public MappedState<Address, CreatedSchemeIds> ManagingSchemeIds { get; set; }
        
        public MappedState<string, MethodFees> TransactionFees { get; set; }

        public SingletonState<AuthorityInfo> MethodFeeController { get; set; }
    }
}