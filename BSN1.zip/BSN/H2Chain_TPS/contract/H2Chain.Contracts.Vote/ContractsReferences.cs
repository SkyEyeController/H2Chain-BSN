﻿using H2Chain.Contracts.MultiToken;
using H2Chain.Contracts.Parliament;

namespace H2Chain.Contracts.Vote
{
    public partial class VoteContractState
    {
        internal TokenContractContainer.TokenContractReferenceState TokenContract { get; set; }
        internal ParliamentContractContainer.ParliamentContractReferenceState ParliamentContract { get; set; }
    }
}