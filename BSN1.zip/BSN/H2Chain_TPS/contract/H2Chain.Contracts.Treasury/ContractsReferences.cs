﻿using H2Chain.Contracts.Consensus.AEDPoS;
using H2Chain.Contracts.Election;
using H2Chain.Contracts.MultiToken;
using H2Chain.Contracts.Parliament;
using H2Chain.Contracts.Profit;
using H2Chain.Contracts.TokenConverter;

namespace H2Chain.Contracts.Treasury
{
    // ReSharper disable InconsistentNaming
    public partial class TreasuryContractState
    {
        internal ProfitContractContainer.ProfitContractReferenceState ProfitContract { get; set; }
        internal TokenContractContainer.TokenContractReferenceState TokenContract { get; set; }
        internal AEDPoSContractContainer.AEDPoSContractReferenceState AEDPoSContract { get; set; }
        internal TokenConverterContractContainer.TokenConverterContractReferenceState TokenConverterContract { get; set; }
        internal ElectionContractContainer.ElectionContractReferenceState ElectionContract { get; set; }
        internal ParliamentContractContainer.ParliamentContractReferenceState ParliamentContract { get; set; }
    }
}