﻿namespace H2Chain.Contracts.Treasury
{
    public static class TreasuryContractConstants
    {
        public const int MaximumReElectionRewardShare = 10;
        public const int DaySec = 86400;
        public const int OneHundredPercent = 100;
    }
}