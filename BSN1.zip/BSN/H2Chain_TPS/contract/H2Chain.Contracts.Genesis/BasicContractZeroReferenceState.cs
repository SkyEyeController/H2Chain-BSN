﻿using H2Chain.Contracts.MultiToken;
using H2Chain.Contracts.Parliament;

namespace H2Chain.Contracts.Genesis
{
    public partial class BasicContractZeroState
    {
        internal ParliamentContractContainer.ParliamentContractReferenceState ParliamentContract { get; set; }
        internal TokenContractContainer.TokenContractReferenceState TokenContract { get; set; }
    }
}