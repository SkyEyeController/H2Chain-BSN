﻿using H2Chain.Sdk.CSharp.State;
using H2Chain.Types;
using H2Chain.Standards.ACS1;

namespace H2Chain.Contracts.Association
{
    public partial class AssociationState : ContractState
    {
        public MappedState<Address, Organization> Organizations { get; set; }
        public MappedState<Hash, ProposalInfo> Proposals { get; set; }
        public MappedState<string, MethodFees> TransactionFees { get; set; }
        public SingletonState<AuthorityInfo> MethodFeeController { get; set; }
    }
}