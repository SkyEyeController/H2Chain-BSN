﻿using H2Chain.Standards.ACS4;
using H2Chain.CSharp.Core.Extension;
using H2Chain.Sdk.CSharp;
using Google.Protobuf;
using Google.Protobuf.WellKnownTypes;

// ReSharper disable once CheckNamespace
namespace H2Chain.Contracts.Consensus.AEDPoS
{
    // ReSharper disable once InconsistentNaming
    public partial class AEDPoSContract
    {
        public class TerminateRoundCommandStrategy : CommandStrategyBase
        {
            private readonly bool _isNewTerm;

            public TerminateRoundCommandStrategy(Round currentRound, string pubkey, Timestamp currentBlockTime,
                bool isNewTerm) : base(
                currentRound, pubkey, currentBlockTime)
            {
                _isNewTerm = isNewTerm;
            }

            public override ConsensusCommand GetAEDPoSConsensusCommand()
            {
                var arrangedMiningTime =
                    MiningTimeArrangingService.ArrangeExtraBlockMiningTime(CurrentRound, Pubkey, CurrentBlockTime);
                return new ConsensusCommand
                {
                    Hint = new H2ChainConsensusHint
                        {
                            Behaviour = _isNewTerm ? H2ChainConsensusBehaviour.NextTerm : H2ChainConsensusBehaviour.NextRound
                        }
                        .ToByteString(),
                    ArrangedMiningTime = arrangedMiningTime,
                    MiningDueTime = arrangedMiningTime.AddMilliseconds(MiningInterval),
                    LimitMillisecondsOfMiningBlock =
                        _isNewTerm ? LastBlockOfCurrentTermMiningLimit : DefaultBlockMiningLimit
                };
            }
        }
    }
}