﻿using H2Chain.CSharp.Core.Extension;
using H2Chain.Sdk.CSharp;
using Google.Protobuf.WellKnownTypes;

// ReSharper disable once CheckNamespace
namespace H2Chain.Contracts.Consensus.AEDPoS
{
    // ReSharper disable once InconsistentNaming
    public partial class AEDPoSContract
    {
        private static class MiningTimeArrangingService
        {
            public static Timestamp ArrangeMiningTimeWithOffset(Timestamp currentBlockTime, int offset)
            {
                return currentBlockTime.AddMilliseconds(offset);
            }

            public static Timestamp ArrangeNormalBlockMiningTime(Round round, string pubkey, Timestamp currentBlockTime)
            {
                return TimestampExtensions.Max(round.GetExpectedMiningTime(pubkey), currentBlockTime);
            }

            public static Timestamp ArrangeExtraBlockMiningTime(Round round, string pubkey, Timestamp currentBlockTime)
            {
                return round.ArrangeAbnormalMiningTime(pubkey, currentBlockTime);
            }
        }
    }
}