﻿using Google.Protobuf.WellKnownTypes;

// ReSharper disable once CheckNamespace
namespace H2Chain.Contracts.Consensus.AEDPoS
{
    // ReSharper disable once InconsistentNaming
    public partial class AEDPoSContract
    {
        private class SideChainConsensusBehaviourProvider : ConsensusBehaviourProviderBase
        {
            public SideChainConsensusBehaviourProvider(Round currentRound, string pubkey, int maximumBlocksCount,
                Timestamp currentBlockTime) : base(currentRound, pubkey, maximumBlocksCount, currentBlockTime)
            {
            }

            /// <summary>
            /// Simply return NEXT_ROUND for side chain.
            /// </summary>
            /// <returns></returns>
            protected override H2ChainConsensusBehaviour GetConsensusBehaviourToTerminateCurrentRound() =>
                H2ChainConsensusBehaviour.NextRound;
        }
    }
}