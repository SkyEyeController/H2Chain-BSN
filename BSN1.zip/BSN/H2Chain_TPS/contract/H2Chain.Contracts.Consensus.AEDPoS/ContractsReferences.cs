﻿using H2Chain.Contracts.Election;
using H2Chain.Contracts.MultiToken;
using H2Chain.Contracts.Parliament;
using H2Chain.Contracts.TokenHolder;
using H2Chain.Contracts.Treasury;

namespace H2Chain.Contracts.Consensus.AEDPoS
{
    // ReSharper disable once InconsistentNaming
    // ReSharper disable UnusedAutoPropertyAccessor.Global
    public partial class AEDPoSContractState
    {
        internal ElectionContractContainer.ElectionContractReferenceState ElectionContract { get; set; }
        internal TreasuryContractImplContainer.TreasuryContractImplReferenceState TreasuryContract { get; set; }
        internal TokenContractContainer.TokenContractReferenceState TokenContract { get; set; }
        internal TokenHolderContractContainer.TokenHolderContractReferenceState TokenHolderContract { get; set; }
        internal ParliamentContractContainer.ParliamentContractReferenceState ParliamentContract { get; set; }
    }
}