﻿using H2Chain.Standards.ACS4;

// ReSharper disable once CheckNamespace
namespace H2Chain.Contracts.Consensus.AEDPoS
{
    public interface IHeaderInformationValidationProvider
    {
        ValidationResult ValidateHeaderInformation(ConsensusValidationContext validationContext);
    }
}