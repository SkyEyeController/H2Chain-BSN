﻿using System.Linq;
using H2Chain.Cryptography.SecretSharing;
using H2Chain.CSharp.Core;
using H2Chain.Types;

namespace H2Chain.Contracts.Consensus.AEDPoS
{
    // ReSharper disable once InconsistentNaming
    public partial class AEDPoSContract
    {
        private void RevealSharedInValues(Round currentRound, string publicKey)
        {
            Context.LogDebug(() => "About to reveal shared in values.");

            if (!currentRound.RealTimeMinersInformation.ContainsKey(publicKey)) return;

            if (!TryToGetPreviousRoundInformation(out var previousRound)) return;

            var minersCount = currentRound.RealTimeMinersInformation.Count;
            var minimumCount = minersCount.Mul(2).Div(3);
            minimumCount = minimumCount == 0 ? 1 : minimumCount;

            foreach (var pair in previousRound.RealTimeMinersInformation.OrderBy(m => m.Value.Order))
            {
                // Skip himsh2c.
                if (pair.Key == publicKey) continue;

                if (!currentRound.RealTimeMinersInformation.Keys.Contains(pair.Key)) continue;

                var publicKeyOfAnotherMiner = pair.Key;
                var anotherMinerInPreviousRound = pair.Value;

                if (anotherMinerInPreviousRound.EncryptedPieces.Count < minimumCount) continue;
                if (anotherMinerInPreviousRound.DecryptedPieces.Count < minersCount) continue;

                // Reveal another miner's in value for target round:

                var orders = anotherMinerInPreviousRound.DecryptedPieces.Select((t, i) =>
                        previousRound.RealTimeMinersInformation.Values
                            .First(m => m.Pubkey ==
                                        anotherMinerInPreviousRound.DecryptedPieces.Keys.ToList()[i]).Order)
                    .ToList();

                var sharedParts = anotherMinerInPreviousRound.DecryptedPieces.Values.ToList()
                    .Select(s => s.ToByteArray()).ToList();

                var revealedInValue =
                    HashHelper.ComputeFrom(SecretSharingHelper.DecodeSecret(sharedParts, orders, minimumCount));

                currentRound.RealTimeMinersInformation[publicKeyOfAnotherMiner].PreviousInValue = revealedInValue;
            }
        }
    }
}