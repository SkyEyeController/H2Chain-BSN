﻿using H2Chain.Standards.ACS0;
using H2Chain.Standards.ACS1;
using H2Chain.Contracts.Election;
using H2Chain.Contracts.MultiToken;
using H2Chain.Contracts.Parliament;
using H2Chain.Contracts.Profit;
using H2Chain.Contracts.TokenConverter;
using H2Chain.Sdk.CSharp.State;
using H2Chain.Types;

namespace H2Chain.Contracts.Economic
{
    public class EconomicContractState : ContractState
    {
        internal TokenContractContainer.TokenContractReferenceState TokenContract { get; set; }
        internal TokenConverterContractContainer.TokenConverterContractReferenceState TokenConverterContract { get; set; }
        internal ElectionContractContainer.ElectionContractReferenceState ElectionContract { get; set; }
        internal ProfitContractContainer.ProfitContractReferenceState ProfitContract { get; set; }
        internal ParliamentContractContainer.ParliamentContractReferenceState ParliamentContract { get; set; }
        internal ACS0Container.ACS0ReferenceState ZeroContract { get; set; }
        internal MappedState<string, MethodFees> TransactionFees { get; set; }

        public SingletonState<bool> Initialized { get; set; }

        public SingletonState<AuthorityInfo> MethodFeeController { get; set; }
    }
}