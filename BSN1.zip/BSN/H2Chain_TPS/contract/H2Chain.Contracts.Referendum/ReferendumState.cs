﻿using H2Chain.Standards.ACS1;
using H2Chain.Standards.ACS3;
using H2Chain.Contracts.MultiToken;
using H2Chain.Contracts.Parliament;
using H2Chain.Sdk.CSharp.State;
using H2Chain.Types;

namespace H2Chain.Contracts.Referendum
{
    public class ReferendumState : ContractState
    {
        internal TokenContractContainer.TokenContractReferenceState TokenContract { get; set; }
        internal ParliamentContractContainer.ParliamentContractReferenceState ParliamentContract { get; set; }

        public BoolState Initialized { get; set; }
        public MappedState<Address, Hash, Receipt> LockedTokenAmount { get; set; }
        public MappedState<Address, Organization> Organizations { get; set; }
        public MappedState<Hash, ProposalInfo> Proposals { get; set; }
        public MappedState<string, MethodFees> TransactionFees { get; set; }
        public SingletonState<AuthorityInfo> MethodFeeController { get; set; }
    }
}