﻿using H2Chain.Contracts.Consensus.AEDPoS;
using H2Chain.Contracts.CrossChain;
using H2Chain.Contracts.Election;
using H2Chain.Contracts.MultiToken;
using H2Chain.Contracts.Profit;
using H2Chain.Contracts.Referendum;
using H2Chain.Contracts.TokenConverter;
using H2Chain.Contracts.TokenHolder;
using H2Chain.Contracts.Treasury;

namespace H2Chain.Contracts.ManagerList
{
    public partial class ManagerListState
    {
        internal AEDPoSContractContainer.AEDPoSContractReferenceState AEDPoSContract { get; set; }
        
        internal CrossChainContractContainer.CrossChainContractReferenceState CrossChainContract { get; set; }
        
        internal ElectionContractContainer.ElectionContractReferenceState ElectionContract { get; set; }
        internal TokenContractContainer.TokenContractReferenceState TokenContract { get; set; }
        internal ProfitContractContainer.ProfitContractReferenceState ProfitContract { get; set; }
        internal ReferendumContractContainer.ReferendumContractReferenceState ReferendumContract { get; set; }
        internal TokenConverterContractContainer.TokenConverterContractReferenceState TokenConverterContract { get; set; }
        internal TokenHolderContractContainer.TokenHolderContractReferenceState TokenHolderContract { get; set; }
        internal TreasuryContractContainer.TreasuryContractReferenceState TreasuryContract { get; set; }
    }
}