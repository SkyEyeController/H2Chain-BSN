﻿using H2Chain.Types;
using Google.Protobuf.WellKnownTypes;
using H2Chain.Kernel;
using H2Chain.Sdk.CSharp;

/*
 * ManagerListContract
 * Author: ShiYang
 * Date: 2022.05.17
 */
namespace H2Chain.Contracts.ManagerList
{
    public  class ManagerListContract : ManagerListContractImplContainer.ManagerListContractImplBase
    {
        private Address _superAdminAddress;
        
        #region Action
        
        /**
         * Initialize function.
         * Auto execute.
         */
        public override Empty Initialize(Empty empty)
        {
            State.AEDPoSContract.Value = Context.GetContractAddressByName(SmartContractConstants.ConsensusContractSystemName);
            State.CrossChainContract.Value = Context.GetContractAddressByName(SmartContractConstants.CrossChainContractSystemName);
            State.ElectionContract.Value = Context.GetContractAddressByName(SmartContractConstants.ElectionContractSystemName);
            State.TokenContract.Value = Context.GetContractAddressByName(SmartContractConstants.TokenContractSystemName);
            State.ProfitContract.Value = Context.GetContractAddressByName(SmartContractConstants.ProfitContractSystemName);
            State.ReferendumContract.Value = Context.GetContractAddressByName(SmartContractConstants.ReferendumContractSystemName);
            State.TokenConverterContract.Value = Context.GetContractAddressByName(SmartContractConstants.TokenConverterContractSystemName);
            State.TokenHolderContract.Value = Context.GetContractAddressByName(SmartContractConstants.TokenHolderContractSystemName);
            State.TreasuryContract.Value = Context.GetContractAddressByName(SmartContractConstants.TreasuryContractSystemName);
            
            State.ManagerList[State.AEDPoSContract.Value] = new BoolValue { Value = true };
            State.ManagerList[State.CrossChainContract.Value] = new BoolValue { Value = true };
            State.ManagerList[State.ElectionContract.Value] = new BoolValue { Value = true };
            State.ManagerList[State.TokenContract.Value] = new BoolValue { Value = true };
            State.ManagerList[State.ProfitContract.Value] = new BoolValue { Value = true };
            State.ManagerList[State.ReferendumContract.Value] = new BoolValue { Value = true };
            State.ManagerList[State.TokenConverterContract.Value] = new BoolValue { Value = true };
            State.ManagerList[State.TokenHolderContract.Value] = new BoolValue { Value = true };
            State.ManagerList[State.TreasuryContract.Value] = new BoolValue { Value = true };
            
            State.SuperAdminLock.Value = false; 
            State.AllowFreeTransfer.Value = true;  // Allow free transfer.
            
            return new Empty();
        }
        
        /**
         * Set super admin address.
         * Can only be called once.
         */
        public override Empty SetSuperAdmin(Address superAdminAddress)
        {
            Assert(!State.SuperAdminLock.Value, "SetSuperAdmin method has been called.");  // SetSuperAdmin method has been called.
            
            // 1. Write the super admin address into state.
            State.SuperAdminAddress.Value = superAdminAddress;
            
            // 2. Add the super admin address to manager list.
            State.ManagerList[superAdminAddress] = new BoolValue { Value = true };

            // 3. Lock the SetSuperAdmin method.
            State.SuperAdminLock.Value = true;  
            
            return new Empty();
        }

        #endregion

        /**
         * Check if the SetSuperAdmin method has been called.
         */
        public override BoolValue HasSetSuperAdmin(Empty empty)
        {
            return new BoolValue { Value = State.SuperAdminLock.Value };
        }

        /**
         * Add the address to manager list.
         */
        public override  Empty AddManager(Address address)
        {
            // Address address = Address.FromBase58(walletAddress.Value);
            
            // 1. validate the SetSuperAdmin method
            Assert(State.SuperAdminLock.Value, "SetSuperAdmin method has not been called yet.");
            // 2. validate the sender's identity
            bool isSuperAdmin = Context.Sender == State.SuperAdminAddress.Value;
            Assert(isSuperAdmin, "Invalid sender.");

            // 3. add the address to manager list
            State.ManagerList[address] = new BoolValue
            {
                Value = true
            };

              return new Empty();
        }

        /**
         * Remove the address from manager list.
         */
        public override Empty RemoveManager(Address address)
        {   
            // 1. validate the SetSuperAdmin method
            Assert(State.SuperAdminLock.Value, "SetSuperAdmin method has not been called yet.");
            
            // 2. validate the sender's identity
            bool isSuperAdmin = Context.Sender == State.SuperAdminAddress.Value;
            Assert(isSuperAdmin, "Invalid sender.");
            
            // 3. remove the address from manager list
            if (State.ManagerList[address] == null)
            {
                // do nothing
            }
            else
            {
                State.ManagerList[address] = new BoolValue
                {
                    Value = false
                };
            }
            return new Empty();
        }

        /**
         * Check if the address is in ManagerList.
         */
        public override BoolValue CheckManager(Address address)
        {            
            if (State.ManagerList[address] != null && State.ManagerList[address].Value == true)
            {
                return  new BoolValue { Value = true };
            }
            // if (State.Manager_Base[address] == null || State.Manager_Base[address].Value == false)
            else
            {
               return  new BoolValue { Value = false };
            }
        }
        
        // #endregion

        
        #region Action
        
        /**
         * Change transfer mode.
         * param:
         *  true:   allow free transfer
         *  false:  not allow free transfer
         */
        public override Empty ChangeTransferMode(BoolValue allow)
        {
            // 1. validate the SetSuperAdmin method
            Assert(State.SuperAdminLock.Value, "SetSuperAdmin method has not been called yet.");
            
            // 2. validate the sender's identity
            bool isSuperAdmin = Context.Sender == State.SuperAdminAddress.Value;
            Assert(isSuperAdmin, "Invalid sender.");
            
            // 3. set if allow free transfer
            State.AllowFreeTransfer.Value = allow.Value;

            return new Empty();
        }
        
        /**
         * Get transfer mode.
         * return:
         *  true:  allow free transfer.
         *  false: not allow free transfer.
         */
        public override BoolValue GetTransferMode(Empty empty)
        {
            return new BoolValue
            {
                Value = State.AllowFreeTransfer.Value
            };
        }
        
        #endregion

        #region ContractBlackList

        /**
         * Add the contract to black list.
         */ 
        public override Empty AddContractToBlackList(Address address)
        {    
            // 1. validate the SetSuperAdmin method
            Assert(State.SuperAdminLock.Value, "SetSuperAdmin method has not been called yet.");

            // 2. validate the sender's identity
            bool isSuperAdmin = Context.Sender == State.SuperAdminAddress.Value;
            Assert(isSuperAdmin, "Invalid sender.");

            // 3. add the contract address to black list
            State.ContractBlackList[address] = new BoolValue
            {
                Value = true
            };

            return new Empty();
        }

        /**
         * Remove the contract from black list.
         */
        public override Empty RemoveContractFromBlackList(Address address)
        {   
            // 1. validate the SetSuperAdmin method
            Assert(State.SuperAdminLock.Value, "SetSuperAdmin method has not been called yet.");
            
            // 2. validate the sender's identity
            bool isSuperAdmin = Context.Sender == State.SuperAdminAddress.Value;
            Assert(isSuperAdmin, "Invalid sender.");
            
            // 3. remove the contract from list
            if (State.ContractBlackList[address] == null)
            {
                // do nothing
            }
            else
            {
                State.ContractBlackList[address] = new BoolValue
                {
                    Value = false
                };
            }
            return new Empty();
        }

        /**
         * Check if the contract is in black list.
         */
        public override BoolValue CheckContractInBlackList(Address address)
        {
            if (State.ContractBlackList[address] != null && State.ContractBlackList[address].Value == true)
            {
                return  new BoolValue { Value = true };
            }
            // if (State.Manager_Base[address] == null || State.Manager_Base[address].Value == false)
            else
            {
               return  new BoolValue { Value = false };
            }
        }        
        
        #endregion

        #region AccountBlackList

        /**
         * Add the account to black list.
         */ 
        public override Empty AddAccountToBlackList(Address address)
        {    
            // 1. validate the SetSuperAdmin method
            Assert(State.SuperAdminLock.Value, "SetSuperAdmin method has not been called yet.");

            // 2. validate the sender's identity
            bool isSuperAdmin = Context.Sender == State.SuperAdminAddress.Value;
            Assert(isSuperAdmin, "Invalid sender.");

            // 3. add the user address to the black list
            State.AccountBlackList[address] = new BoolValue
            {
                Value = true
            };

            return new Empty();
        }

        /**
         * Remove the account from black list.
         */
        public override Empty RemoveAccountFromBlackList(Address address)
        {   
            // 1. validate the SetSuperAdmin method
            Assert(State.SuperAdminLock.Value, "SetSuperAdmin method has not been called yet.");
            
            // 2. validate sender' identity
            bool isSuperAdmin = Context.Sender == State.SuperAdminAddress.Value;
            Assert(isSuperAdmin, "Invalid sender.");
            
            // 3. remove the user address from black list
            if (State.AccountBlackList[address] == null)
            {
                // do nothing
            }
            else
            {
                State.AccountBlackList[address] = new BoolValue
                {
                    Value = false
                };
            }
            return new Empty();
        }

        /**
         * Check if the account is in black list.
         */
        public override BoolValue CheckAccountInBlackList(Address address)
        {
            if (State.AccountBlackList[address] != null && State.AccountBlackList[address].Value == true)
            {
                return  new BoolValue { Value = true };
            }
            // if (State.Manager_Base[address] == null || State.Manager_Base[address].Value == false)
            else
            {
               return  new BoolValue { Value = false };
            }
        }        



        #endregion

        #region DestroyedContractList

        /**
         * Add the contract to destroyed list.
         */ 
        public override Empty AddContractToDestroyedList(Address address)
        {    
            // 1. validate the SetSuperAdmin method
            Assert(State.SuperAdminLock.Value, "SetSuperAdmin method has not been called yet.");

            // 2. validate the sender's identity
            bool isSuperAdmin = Context.Sender == State.SuperAdminAddress.Value;
            Assert(isSuperAdmin, "Invalid sender.");

            // 3. add the user address to the Destroyed ContractList
            State.DestroyedContractList[address] = new BoolValue
            {
                Value = true
            };

            return new Empty();
        }

        /**
         * Check if the contract is in the destroyed list.
         */
        public override BoolValue CheckContractInDestroyedList(Address address)
        {
            if (State.DestroyedContractList[address] != null && State.DestroyedContractList[address].Value == true)
            {
                return  new BoolValue { Value = true };
            }
            // if (State.Manager_Base[address] == null || State.Manager_Base[address].Value == false)
            else
            {
               return  new BoolValue { Value = false };
            }
        }        



        #endregion

        /**
         * Moethod for test.
         */
        public override StringValue TestMySystemContract(Empty empty)
        {

            return new StringValue
            {
                Value = "success"
            };
        }
    }
}

