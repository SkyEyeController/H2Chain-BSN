﻿using H2Chain.Contracts.MultiToken;
using H2Chain.Contracts.Parliament;
using H2Chain.Contracts.Profit;

namespace H2Chain.Contracts.TokenHolder
{
    public partial class TokenHolderContractState
    {
        internal TokenContractContainer.TokenContractReferenceState TokenContract { get; set; }
        internal ProfitContractContainer.ProfitContractReferenceState ProfitContract { get; set; }
        internal ParliamentContractContainer.ParliamentContractReferenceState ParliamentContract { get; set; }
    }
}