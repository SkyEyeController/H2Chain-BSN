﻿using H2Chain.Standards.ACS10;
using H2Chain.Contracts.Consensus.AEDPoS;
using H2Chain.Contracts.MultiToken;
using H2Chain.Contracts.Profit;
using H2Chain.Contracts.Vote;
using H2Chain.Contracts.Parliament;

namespace H2Chain.Contracts.Election
{
    // ReSharper disable InconsistentNaming
    public partial class ElectionContractState
    {
        internal VoteContractContainer.VoteContractReferenceState VoteContract { get; set; }
        internal ProfitContractContainer.ProfitContractReferenceState ProfitContract { get; set; }
        internal TokenContractContainer.TokenContractReferenceState TokenContract { get; set; }
        internal AEDPoSContractContainer.AEDPoSContractReferenceState AEDPoSContract { get; set; }
        internal ParliamentContractContainer.ParliamentContractReferenceState ParliamentContract { get; set; }
        internal DividendPoolContractContainer.DividendPoolContractReferenceState DividendPoolContract{ get; set; }
    }
}