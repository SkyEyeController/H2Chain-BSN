﻿using H2Chain.Standards.ACS1;
using H2Chain.Contracts.MultiToken;
using H2Chain.Contracts.Parliament;
using H2Chain.Sdk.CSharp.State;
using H2Chain.Standards.ACS10;
using H2Chain.Types;

namespace H2Chain.Contracts.TokenConverter
{
    public class TokenConverterContractState : ContractState
    {
        internal TokenContractContainer.TokenContractReferenceState TokenContract { get; set; }
        internal ParliamentContractContainer.ParliamentContractReferenceState ParliamentContract { get; set; }
        internal DividendPoolContractContainer.DividendPoolContractReferenceState DividendPoolContract { get; set; }

        public StringState BaseTokenSymbol { get; set; }
        public StringState FeeRate { get; set; }
        public MappedState<string, Connector> Connectors { get; set; }
        public MappedState<string, MethodFees> TransactionFees { get; set; }
        public MappedState<string, long> DepositBalance { get; set; }
        public SingletonState<AuthorityInfo> ConnectorController { get; set; }
        public SingletonState<AuthorityInfo> MethodFeeController { get; set; }
    }
}