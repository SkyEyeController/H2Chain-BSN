﻿using H2Chain.Sdk.CSharp;

namespace H2Chain.Contracts.TokenConverter
{
    public class InvalidValueException : BaseH2ChainException
    {
        public InvalidValueException(string message) : base(message)
        {
        }
    }
}