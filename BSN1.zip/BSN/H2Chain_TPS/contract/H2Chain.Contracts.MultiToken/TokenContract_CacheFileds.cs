﻿namespace H2Chain.Contracts.MultiToken
{
    public partial class TokenContract
    {
        private string _primaryTokenSymbol;
    }
}