﻿using H2Chain.Standards.ACS10;
using H2Chain.Contracts.Association;
using H2Chain.Contracts.Consensus.AEDPoS;
using H2Chain.Contracts.Parliament;
using H2Chain.Contracts.Referendum;
using H2Chain.Contracts.ManagerList;

namespace H2Chain.Contracts.MultiToken
{
    public partial class TokenContractState
    {
        internal ManagerListContractContainer.ManagerListContractReferenceState ManagerListContract { get; set; }
        internal ParliamentContractContainer.ParliamentContractReferenceState ParliamentContract { get; set; }
        internal AssociationContractContainer.AssociationContractReferenceState AssociationContract { get; set; }
        internal ReferendumContractContainer.ReferendumContractReferenceState ReferendumContract { get; set; }
        internal AEDPoSContractContainer.AEDPoSContractReferenceState ConsensusContract { get; set; }
        internal DividendPoolContractContainer.DividendPoolContractReferenceState DividendPoolContract{ get; set; }
    }
}