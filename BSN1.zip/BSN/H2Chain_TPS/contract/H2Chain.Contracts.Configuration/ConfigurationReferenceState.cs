﻿using H2Chain.Contracts.MultiToken;
using H2Chain.Contracts.Parliament;

namespace H2Chain.Contracts.Configuration
{
    public partial class ConfigurationState
    {
        internal ParliamentContractContainer.ParliamentContractReferenceState ParliamentContract { get; set; }
        internal TokenContractContainer.TokenContractReferenceState TokenContract { get; set; }
    }
}