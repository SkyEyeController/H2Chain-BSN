﻿using H2Chain.Standards.ACS11;
using H2Chain.Standards.ACS0;
using H2Chain.Contracts.Association;
using H2Chain.Contracts.MultiToken;
using H2Chain.Contracts.Parliament;

namespace H2Chain.Contracts.CrossChain
{
    public partial class CrossChainContractState
    {
        internal TokenContractContainer.TokenContractReferenceState TokenContract { get; set; }
        internal AssociationContractContainer.AssociationContractReferenceState AssociationContract { get; set; }
        internal ACS0Container.ACS0ReferenceState GenesisContract { get; set; }
        internal ParliamentContractContainer.ParliamentContractReferenceState ParliamentContract { get; set; }

        internal CrossChainInteractionContractContainer.CrossChainInteractionContractReferenceState
            CrossChainInteractionContract { get; set; }
    }
}