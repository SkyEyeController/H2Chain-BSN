﻿# H2Chain - A Decentralized Cloud Computing Blockchain Network 

[![GitHub closed issues](https://img.shields.io/github/issues-closed/h2chainproject/h2chain.svg)](https://app.gitkraken.com/glo/board/XKsOZJarBgAPseno)
[![lisence](https://img.shields.io/github/license/H2ChainProject/H2Chain.svg)](https://github.com/H2ChainProject/H2Chain/blob/dev/LICENSE)
[![Nuget](https://img.shields.io/nuget/v/H2Chain.OS.svg)](https://www.nuget.org/packages?q=h2chain)
[![MyGet (with prereleases)](https://img.shields.io/myget/h2chain-project-dev/vpre/h2chain.os.svg?label=myget)](https://www.myget.org/gallery/h2chain-project-dev)
[![Twitter Follow](https://img.shields.io/twitter/follow/h2chainblockchain.svg?label=%40h2chainblockchain&style=social)](https://twitter.com/h2chainblockchain)
[![Telegram](https://badgen.net/badge/telegram/join/blue?icon=telegram)](https://t.me/h2chaindeveloper)

BRANCH | TRAVIS CI | AZURE PIPELINES | TESTS | CODE COVERAGE
-------|-----------|-----------------|-------|--------------
MASTER |[![Build Status](https://travis-ci.org/H2ChainProject/H2Chain.svg?branch=master)](https://travis-ci.org/H2ChainProject/H2Chain) | [![Build Status](https://dev.azure.com/H2ChainProject/H2Chain/_apis/build/status/H2ChainProject.H2Chain?branchName=master)](https://dev.azure.com/H2ChainProject/H2Chain/_build/latest?definitionId=1&branchName=master) | [![Test Status](https://img.shields.io/azure-devops/tests/H2ChainProject/H2Chain/1/master)](https://dev.azure.com/H2ChainProject/H2Chain/_build/latest?definitionId=1&branchName=master) | [![codecov](https://codecov.io/gh/H2ChainProject/H2Chain/branch/master/graph/badge.svg)](https://codecov.io/gh/H2ChainProject/H2Chain)
DEV    |[![Build Status](https://travis-ci.org/H2ChainProject/H2Chain.svg?branch=dev)](https://travis-ci.org/H2ChainProject/H2Chain) | [![Build Status](https://dev.azure.com/H2ChainProject/H2Chain/_apis/build/status/H2ChainProject.H2Chain?branchName=dev)](https://dev.azure.com/H2ChainProject/H2Chain/_build/latest?definitionId=1&branchName=dev) | [![Test Status](https://img.shields.io/azure-devops/tests/H2ChainProject/H2Chain/1/dev)](https://dev.azure.com/H2ChainProject/H2Chain/_build/latest?definitionId=1&branchName=dev) | [![codecov](https://codecov.io/gh/H2ChainProject/H2Chain/branch/dev/graph/badge.svg)](https://codecov.io/gh/H2ChainProject/H2Chain)

Welcome to H2Chain's official GitHub repo ! 

H2Chain is a blockchain system aiming to achieve scalability and extensibility through the use of side-chains and a flexible design. To support multiple use cases H2Chain makes it as easy as possible to extend/customize the system by providing easy to use tools and frameworks in order to customize the chains and write smart contracts. H2Chain will eventually support various languages that will let developers choose the one they are the most comfortable with.

For more information you can follow these links:
* [Official website](https://h2chain.io)
* [Documentation](https://docs.h2chain.io/en/latest/)
    * [Environment setup](https://docs.h2chain.io/en/latest/getting-started/development-environment/environment-setup.html)
    * [Running a node](https://docs.h2chain.io/en/latest/getting-started/development-environment/docker.html)
    * [Smart contract development](https://docs.h2chain.io/en/latest/getting-started/smart-contract-development/index.html)
    * [Web Api](https://docs.h2chain.io/en/latest/reference/web-api/web-api.html)
    * [Testnet](https://docs.h2chain.io/en/latest/tutorials/testnet.html)
* [White Paper](https://h2chain.io/gridcn/h2chain_whitepaper_EN.pdf) 

This repository contains the code that runs an H2Chain node, you'll find bellow other important repositories in the H2Chain 
ecosystem:

TOOL/LIBRARY | description
-------------|-------------
[h2chain-sdk.js](https://docs.h2chain.io/en/latest/reference/chain-sdk/javascript/js-sdk.html) | Javascript development kit for interacting with an H2Chain node, useful for dApp developers. 
[h2chain-command](https://docs.h2chain.io/en/latest/reference/cli/methods.html) | CLI tool for interacting with an H2Chain node and wallet.
[h2chain-boilerplate](https://h2chain-boilerplate-docs.readthedocs.io/en/latest/) | framework for smart contract and dApp development.

## Getting Started

### This repository

This repo is where you will find the code that can use to run an H2Chain node. It also contains a **tests** folder that centralizes all the unit tests.

### Documentation

We strongly recommend you follow official documentation that will guide you through installing dependencies and running the node, 
these two guides will get you started:  
* [Environment setup](https://docs.h2chain.io/en/latest/getting-started/development-environment/environment-setup.html)  
* [Running a node](https://docs.h2chain.io/en/latest/getting-started/development-environment/docker.html)  

## Contributing

If you have a reasonable understanding of blockchain technology and at least some notions of C# you can of course contribute. We also appreciate other types of contributions such as documentation improvements or even correcting typos in the code if you spot any.

We expect every contributor to be respectful and constructive so that everyone has a positive experience, you can find out more in our [code of conduct](https://github.com/H2ChainProject/H2Chain/blob/dev/CODE_OF_CONDUCT.md).

### Reporting an issue

We currently only use GitHub for tracking issues, feature request and pull requests. If you're not familiar with these tools have a look at the [GitHub](https://help.github.com/en) documentation.

#### Bug report

If you think you have found a bug in our system feel free to open a GitHub issue, but first:
- check with GitHub's search engine that the bug doesn't already exist.
- in the request give as much information as possible such as: the OS, the version of H2Chain, how to reproduce...

#### Missing feature

We also use the GitHub issue tracker for features. If you think that some piece of functionality is missing in H2Chain, you can open an issue with the following in mind:
- check for similare feature requests already open.
- provide as much detail and context as possible.
- be as convincing as possible as to why we need this feature and how everybody can benefit from it.

### Pull request

For any non trivial modification of the code, the pull requests should be associated with an issue that was previously discussed. During the time you implement and are not yet ready for review, prefix the PR's title with ```[WIP]``` and also don't forget to do the following:
- add a description in the pull request saying which issue you are fixing/implementing. 
- be as explicit as possible about the changes in the description.
- add the tests corresponding to your modifications.
- pull requests should be made against the **dev** branch.

When you are ready for a review by the core team, just remove ```[WIP]``` from your PR's title and others will review. This will either lead to a discussion or to a refactor of the code. The Travis CI system makes sure that every pull request is built for Windows, Linux, and macOS, and that unit tests are run automatically. The CI passing is a pre-condition for the PR to be merged as well as the approval from the core team.

## Versioning

We use Semantic Versioning (SemVer) for versioning, if you're intereted in closely following H2Chain's developement please check out the [SemVer docs](https://semver.org/).

## License

H2Chain is licenced under [MIT](https://github.com/H2ChainProject/H2Chain/blob/dev/LICENSE)
