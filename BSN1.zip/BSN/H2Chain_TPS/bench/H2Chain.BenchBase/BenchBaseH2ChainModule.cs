﻿using H2Chain.Modularity;
using H2Chain.TestBase;
using Volo.Abp.Modularity;

namespace H2Chain.BenchBase
{
    [DependsOn(typeof(TestBaseH2ChainModule))]
    public class BenchBaseH2ChainModule : H2ChainModule
    {
        
    }
    
    public class BenchBaseTest<TModule> : H2ChainIntegratedTest<TModule>
        where TModule: IAbpModule
    {
    }

    public class BenchBaseTest : H2ChainIntegratedTest<TestBaseH2ChainModule>
    {
        
    }
}