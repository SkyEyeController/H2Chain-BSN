﻿using H2Chain.BenchBase;
using Volo.Abp.Modularity;

namespace H2Chain.Database.Benches
{
    public class DatabaseBenchH2ChainModule : BenchBaseH2ChainModule
    {
        public override void ConfigureServices(ServiceConfigurationContext context)
        {
            context.Services.AddKeyValueDbContext<DbContext>(o => o.UseInMemoryDatabase());
        }
    }
}