﻿namespace H2Chain.Database.Benches
{
    class DbContext : KeyValueDbContext<DbContext>
    {
    }
}