﻿using System.Threading.Tasks;
using H2Chain.Kernel;
using H2Chain.OS;
using H2Chain.Types;
using BenchmarkDotNet.Attributes;

namespace H2Chain.Benchmark
{
    [MarkdownExporterAttribute.GitHub]
    public class TransactionVerifySignatureTests : BenchmarkTestBase
    {
        private OSTestHelper _osTestHelper;

        private Transaction _transaction;

        [GlobalSetup]
        public async Task GlobalSetup()
        {
            _osTestHelper = GetRequiredService<OSTestHelper>();

            _transaction = await _osTestHelper.GenerateTransferTransaction();
        }

        [Benchmark]
        public void VerifySignatureTest()
        {
            _transaction.VerifySignature();
        }
    }
}