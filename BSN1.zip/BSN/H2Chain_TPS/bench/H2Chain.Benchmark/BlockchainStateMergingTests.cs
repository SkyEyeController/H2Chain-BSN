﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using H2Chain.Kernel;
using H2Chain.Kernel.Blockchain;
using H2Chain.Kernel.Blockchain.Application;
using H2Chain.Kernel.Blockchain.Domain;
using H2Chain.Kernel.Blockchain.Events;
using H2Chain.Kernel.Blockchain.Infrastructure;
using H2Chain.Kernel.Infrastructure;
using H2Chain.Kernel.SmartContract.Application;
using H2Chain.Kernel.SmartContract.Domain;
using H2Chain.Kernel.SmartContract.Infrastructure;
using H2Chain.Kernel.TransactionPool.Application;
using H2Chain.OS;
using BenchmarkDotNet.Attributes;

namespace H2Chain.Benchmark
{
    [MarkdownExporterAttribute.GitHub]
    public class BlockchainStateMergingTests : BenchmarkTestBase
    {
        private IStateStore<ChainStateInfo> _chainStateInfoCollection;
        private IBlockchainStore<Chain> _chains;
        private IBlockManager _blockManager;
        private ITransactionManager _transactionManager;
        private IBlockchainStateService _blockchainStateService;
        private IBlockStateSetManger _blockStateSetManger;
        private IBlockchainService _blockchainService;
        private IChainManager _chainManager;
        private ITransactionPoolService _transactionPoolService;
        private OSTestHelper _osTestHelper;

        private Chain _chain;
        private ChainStateInfo _chainStateInfo;
        private List<BlockStateSet> _blockStateSets;
        private List<Block> _blocks;

        [Params(1, 10, 50)] public int BlockCount;

        [Params(1, 10, 100, 1000, 3000, 5000)] public int TransactionCount;

        [GlobalSetup]
        public async Task GlobalSetup()
        {
            _chains = GetRequiredService<IBlockchainStore<Chain>>();
            _chainStateInfoCollection = GetRequiredService<IStateStore<ChainStateInfo>>();
            _blockchainStateService = GetRequiredService<IBlockchainStateService>();
            _blockStateSetManger = GetRequiredService<IBlockStateSetManger>();
            _blockchainService = GetRequiredService<IBlockchainService>();
            _osTestHelper = GetRequiredService<OSTestHelper>();
            _chainManager = GetRequiredService<IChainManager>();
            _blockManager = GetRequiredService<IBlockManager>();
            _transactionManager = GetRequiredService<ITransactionManager>();
            _transactionPoolService = GetRequiredService<ITransactionPoolService>();
            

            _blockStateSets = new List<BlockStateSet>();
            _blocks = new List<Block>();

            _chain = await _blockchainService.GetChainAsync();

            var blockHash = _chain.BestChainHash;
            while (true)
            {
                var blockState = await _blockStateSetManger.GetBlockStateSetAsync(blockHash);
                _blockStateSets.Add(blockState);

                var blockHeader = await _blockchainService.GetBlockHeaderByHashAsync(blockHash);
                blockHash = blockHeader.PreviousBlockHash;
                if (blockHash == _chain.LastIrreversibleBlockHash)
                {
                    break;
                }
            }

            await _blockchainStateService.MergeBlockStateAsync(_chain.BestChainHeight, _chain.BestChainHash);

            for (var i = 0; i < BlockCount; i++)
            {
                var transactions = await _osTestHelper.GenerateTransferTransactions(TransactionCount);
                await _osTestHelper.BroadcastTransactions(transactions);
                var block = await _osTestHelper.MinedOneBlock();
                _blocks.Add(block);

                var blockState = await _blockStateSetManger.GetBlockStateSetAsync(block.GetHash());
                _blockStateSets.Add(blockState);
            }

            var chain = await _blockchainService.GetChainAsync();
            await _chainManager.SetIrreversibleBlockAsync(chain, chain.BestChainHash);

            _chainStateInfo = await _chainStateInfoCollection.GetAsync(chain.Id.ToStorageKey());
        }

        [Benchmark]
        public async Task MergeBlockStateTest()
        {
            var chain = await _blockchainService.GetChainAsync();
            await _blockchainStateService.MergeBlockStateAsync(chain.BestChainHeight, chain.BestChainHash);
        }

        [IterationCleanup]
        public async Task IterationCleanup()
        {
            await _chainStateInfoCollection.SetAsync(_chain.Id.ToStorageKey(), _chainStateInfo);
            foreach (var blockStateSet in _blockStateSets)
            {
                await _blockStateSetManger.SetBlockStateSetAsync(blockStateSet);
            }
        }

        [GlobalCleanup]
        public async Task GlobalCleanup()
        {
            foreach (var block in _blocks)
            {
                await _transactionPoolService.CleanByTransactionIdsAsync(block.TransactionIds);

                await _transactionManager.RemoveTransactionsAsync(block.Body.TransactionIds);
                await RemoveTransactionResultsAsync(block.Body.TransactionIds, block.GetHash());
                await _chainManager.RemoveChainBlockLinkAsync(block.GetHash());
                await _blockManager.RemoveBlockAsync(block.GetHash());
            }

            await _transactionPoolService.UpdateTransactionPoolByBestChainAsync(_chain.BestChainHash,
                _chain.BestChainHeight);

            await _chains.SetAsync(_chain.Id.ToStorageKey(), _chain);
        }
    }
}