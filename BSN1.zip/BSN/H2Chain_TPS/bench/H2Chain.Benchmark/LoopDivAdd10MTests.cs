﻿using System;
using System.Threading.Tasks;
using H2Chain.Benchmark.PerformanceTestContract;
using H2Chain.Kernel;
using H2Chain.Kernel.Blockchain.Application;
using H2Chain.Kernel.SmartContract.Application;
using H2Chain.OS;
using H2Chain.Types;
using BenchmarkDotNet.Attributes;
using Google.Protobuf.WellKnownTypes;

namespace H2Chain.Benchmark
{
    [MarkdownExporterAttribute.GitHub]
    public class LoopDivAdd10MTests : BenchmarkTestBase
    {
        private IBlockchainService _blockchainService;
        private ITransactionReadOnlyExecutionService _transactionReadOnlyExecutionService;
        private OSTestHelper _osTestHelper;

        private Transaction _transaction;
        private Address _contractAddress;
        private Chain _chain;
        private TransactionTrace _transactionTrace;

        private const double ExecuteResult = 501.67224080267556;

        [GlobalSetup]
        public async Task GlobalSetup()
        {
            _blockchainService = GetRequiredService<IBlockchainService>();
            _transactionReadOnlyExecutionService = GetRequiredService<ITransactionReadOnlyExecutionService>();
            _osTestHelper = GetRequiredService<OSTestHelper>();

            _contractAddress = await _osTestHelper.DeployContract<PerformanceTestContract.PerformanceTestContract>();
            _chain = await _blockchainService.GetChainAsync();
        }

        [IterationSetup]
        public void IterationSetup()
        {
            _transaction = _osTestHelper.GenerateTransaction(SampleAddress.AddressList[0], _contractAddress,
                nameof(PerformanceTestContract.PerformanceTestContract.LoopDivAdd), new DivAddTestInput()
                {
                    X = 100,
                    Y = 300,
                    K = 500,
                    N = 10000000
                });
        }

        [Benchmark]
        public async Task LoopDivAdd10M()
        {
            _transactionTrace = await _transactionReadOnlyExecutionService.ExecuteAsync(new ChainContext
                {
                    BlockHash = _chain.BestChainHash,
                    BlockHeight = _chain.BestChainHeight
                },
                _transaction,
                TimestampHelper.GetUtcNow());
        }

        [IterationCleanup]
        public void IterationCleanup()
        {
            var calResult = DoubleValue.Parser.ParseFrom(_transactionTrace.ReturnValue).Value;
            if (calResult != ExecuteResult)
            {
                throw new Exception("execute fail");
            }
        }
    }
}