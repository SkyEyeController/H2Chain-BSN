﻿using H2Chain.Cryptography;
using H2Chain.Kernel;
using H2Chain.Kernel.Account.Application;
using H2Chain.Kernel.Account.Infrastructure;
using H2Chain.Kernel.Consensus.Application;
using H2Chain.Kernel.SmartContract;
using H2Chain.Modularity;
using H2Chain.OS;
using H2Chain.Kernel.SmartContract.Parallel;
using H2Chain.OS.Network.Infrastructure;
using H2Chain.Runtime.CSharp;
using Microsoft.Extensions.DependencyInjection;
using Moq;
using Volo.Abp;
using Volo.Abp.Modularity;

namespace H2Chain.Benchmark
{
    [DependsOn(
        typeof(OSCoreWithChainTestH2ChainModule)
    )]
    public class BenchmarkH2ChainModule : H2ChainModule
    {
        public override void ConfigureServices(ServiceConfigurationContext context)
        {
        }
    }

    [DependsOn(
        typeof(CoreOSH2ChainModule),
        typeof(KernelH2ChainModule),
        typeof(CSharpRuntimeH2ChainModule),
        typeof(TestBaseKernelH2ChainModule)
    )]
    public class MiningBenchmarkH2ChainModule : H2ChainModule
    {
        public override void ConfigureServices(ServiceConfigurationContext context)
        {
            context.Services.AddSingleton(o => Mock.Of<IH2ChainNetworkServer>());
            context.Services.AddTransient<AccountService>();
            context.Services.AddTransient(o => Mock.Of<IConsensusService>());
            // Configure<TransactionOptions>(options => options.EnableTransactionExecutionValidation = false);
            Configure<HostSmartContractBridgeContextOptions>(options =>
            {
                options.ContextVariables[ContextVariableDictionary.NativeSymbolName] = "H2C";
            });
        }

        public override void OnPreApplicationInitialization(ApplicationInitializationContext context)
        {
            var keyPairProvider = context.ServiceProvider.GetRequiredService<IH2ChainAsymmetricCipherKeyPairProvider>();
            keyPairProvider.SetKeyPair(CryptoHelper.GenerateKeyPair());
        }
    }

    [DependsOn(
        typeof(OSCoreWithChainTestH2ChainModule),
        typeof(ParallelExecutionModule)
    )]
    public class BenchmarkParallelH2ChainModule : H2ChainModule
    {
        public override void ConfigureServices(ServiceConfigurationContext context)
        {
        }
    }
}