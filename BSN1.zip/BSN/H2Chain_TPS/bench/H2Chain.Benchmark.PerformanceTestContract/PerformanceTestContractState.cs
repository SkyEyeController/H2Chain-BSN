﻿using H2Chain.Sdk.CSharp.State;

namespace H2Chain.Benchmark.PerformanceTestContract
{
    public class PerformanceTestContractState: ContractState
    {
        
    }
}