﻿#!/bin/bash
BIND_VOLUME='-v /opt:/opt'
CONFIGURE_PATH='-w /opt/h2chain-node'
docker run -it --rm   $BIND_VOLUME $CONFIGURE_PATH   h2chain/node

