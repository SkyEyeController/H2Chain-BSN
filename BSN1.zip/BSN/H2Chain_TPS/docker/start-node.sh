﻿#!/bin/bash
PUBLISH_PORT='-p 6800:6800 -p 8000:8000'
BIND_VOLUME='-v /opt:/opt'
CONfIGURE_PATH='/opt/h2chain-node'
docker run -itd $PUBLISH_PORT  $BIND_VOLUME -w  $CONfIGURE_PATH  h2chain/node  dotnet /app/H2Chain.Launcher.dll  --config.path $CONfIGURE_PATH
