﻿# Architecture

This section is for **advanced** users, it explains the architectural concepts behind the node's design.

