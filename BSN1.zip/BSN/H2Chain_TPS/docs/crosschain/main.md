﻿# Cross chain

Information about how H2Chain implements side chains.