﻿# H2Chain documentation

You will find here the markdown for H2Chain's documentation.