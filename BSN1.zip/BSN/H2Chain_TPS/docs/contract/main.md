﻿# Smart contracts

An advanced section with in-depth explanations of H2Chain smart contracts.