﻿## Smart contract update

#### change owner

- modify the contract, build dll
- cli to update -> same address
- smart contract zero

#### change the code
